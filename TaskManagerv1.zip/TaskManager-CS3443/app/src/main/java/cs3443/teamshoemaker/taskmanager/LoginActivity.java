package cs3443.teamshoemaker.taskmanager;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


public class LoginActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Add your login functionality here
        // e.g., handle login button, authenticate user, etc.
    }
}

