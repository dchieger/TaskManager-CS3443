package cs3443.teamshoemaker.taskmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;

public class journal extends AppCompatActivity {

    FloatingActionButton addJournalBtn;
// JournalActivity

    File dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
    File[] files = dir.listFiles();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_journal);

        addJournalBtn = findViewById(R.id.add_journal_btn);

        addJournalBtn.setOnClickListener((v)-> startActivity(new Intent(journal.this,JournalDetails.class
        )) );
    }
}