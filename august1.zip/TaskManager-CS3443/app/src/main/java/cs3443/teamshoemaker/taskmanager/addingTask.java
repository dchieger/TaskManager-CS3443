package cs3443.teamshoemaker.taskmanager;

import android.os.Bundle;
import android.util.JsonWriter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class addingTask extends AppCompatActivity {

    EditText taskName;
    EditText taskDescription;
    Button addTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_task);

        // get logged in user
        // Get the logged-in user's email from the intent
        String loggedInUserEmail = getIntent().getStringExtra("email");

        taskName = findViewById(R.id.editTextTaskName);
        taskDescription = findViewById(R.id.task_description);
        addTask = findViewById(R.id.addTaskbutton);

        // Set a click listener on the addTask button
        // ...

// Set a click listener on the addTask button
        addTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get user input
                String TName = taskName.getText().toString();
                String TDescription = taskDescription.getText().toString();

                // Create JSON object for the new task with the logged-in user's email
                JSONObject newTask = new JSONObject();
                try {
                    newTask.put("email", loggedInUserEmail); // Add the email of the logged-in user
                    newTask.put("title", TName);
                    newTask.put("description", TDescription);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                // Load existing tasks from the file
                String filename = "taskDB.json";
                JSONArray existingTasks = new JSONArray();
                // ...

// Write the updated tasks back to the file
                try (FileOutputStream fos = openFileOutput(filename, MODE_PRIVATE);
                     Writer writer = new OutputStreamWriter(fos)) {

                    // Prepare the JSON data to be written to the file
                    JSONObject jsonData = new JSONObject();
                    jsonData.put("Tasks", existingTasks);

                    // Use JsonWriter for formatting
                    JsonWriter jsonWriter = new JsonWriter(writer);
                    jsonWriter.setIndent("  "); // Set the indentation (you can use "\t" for tabs)

                    // Convert the jsonData to a string using JSONArray's toString method
                    JSONArray jsonArray = new JSONArray();
                    jsonArray.put(jsonData);
                    String jsonString = jsonArray.toString();

                    // Write the JSON data string directly to the JsonWriter
                    jsonWriter.value(jsonString);

                    jsonWriter.close(); // Make sure to close the JsonWriter

                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(addingTask.this, "Failed to write the file.", Toast.LENGTH_SHORT).show();
                }



                // Add the new task to the existing tasks
                existingTasks.put(newTask);

                // Log the existing tasks after adding the new task
                Log.d("UpdatedTasks", existingTasks.toString());

                // Write the updated tasks back to the file
                try (FileOutputStream fos = openFileOutput(filename, MODE_PRIVATE);
                     Writer writer = new OutputStreamWriter(fos)) {

                    // Use JsonWriter for formatting
                    JsonWriter jsonWriter = new JsonWriter(writer);
                    jsonWriter.setIndent("  "); // Set the indentation (you can use "\t" for tabs)
                    jsonWriter.value(existingTasks.toString());
                    jsonWriter.close(); // Make sure to close the JsonWriter

                    // Log the JSON data being written to the file
                    Log.d("UpdatedJsonData", existingTasks.toString());

                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(addingTask.this, "Failed to write the file.", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
